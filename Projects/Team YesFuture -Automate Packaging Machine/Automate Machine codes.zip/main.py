import machine
import time
from machine import Pin, SoftI2C
from lcd_api import LcdApi
from i2c_lcd import I2cLcd
from time import sleep

I2C_ADDR = 0x27
totalRows = 2
totalColumns = 16
led = Pin(14, Pin.OUT) 
door = Pin(23, Pin.OUT) 

push_button = Pin(4, Pin.IN)  
agilrikArttirBtn = Pin(2, Pin.IN)  
ArttirBtn = Pin(4, Pin.IN)  
AzaltBtn = Pin(5, Pin.IN)  
StartBtn = Pin(18, Pin.IN)  
StopBtn = Pin(19, Pin.IN)  


agirlik=0
gAyar=0
kontrol=0

i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=10000)     #initializing the I2C method for ESP32
#i2c = I2C(scl=Pin(5), sda=Pin(4), freq=10000)       #initializing the I2C method for ESP8266

lcd = I2cLcd(i2c, I2C_ADDR, totalRows, totalColumns)

x=1

y=1

logic_state = push_button.value()


if x==1:
    lcd.move_to(3,0)
    lcd.putstr("yesFuture")

    sleep(2)
    lcd.clear()


while y==1:

    agilrikArttirBtnDurum = agilrikArttirBtn.value()
    ArttirBtnDurum = ArttirBtn.value()
    AzaltBtnDurum = AzaltBtn.value()
    StartBtnDurum = StartBtn.value()
    StopBtnDurum = StopBtn.value()

    if ArttirBtnDurum ==1:
      gAyar=gAyar+1
    if AzaltBtnDurum ==1:
      gAyar=gAyar-1
      if gAyar<0:
        gAyar=0


    if agilrikArttirBtnDurum ==1:
      agirlik=agirlik+1
      AgilrikArttirBtnDurum=0
    
    if StartBtnDurum ==1:
          kontrol=1
          led.value(1)   
  
    if StopBtnDurum ==1:
          kontrol=0

    if kontrol==0:
       led.value(0)

    if kontrol==1:
      if gAyar<agirlik:
       led.value(1)   
       door.value(1)
       sleep(2)
      if gAyar == agirlik:
        led.value(0)
        sleep(2)
        agirlik=0   
        lcd.clear()
    lcd.move_to(7,0)
    lcd.putstr(str(agirlik))
    lcd.move_to(7,1)
    lcd.putstr(str(gAyar))

 
 