from machine import Pin,I2C 
from time import sleep,sleep_ms,ticks_ms
from i2c_lcd import I2cLcd
import dht
sensor=dht.DHT22(Pin(14))
AddressOfLcd=0x27
i2c=I2C(scl=Pin(22),sda=Pin(21),
freq=400000)
lcd=I2cLcd(i2c,AddressOfLcd,2,16)
def testLcd(temp,hum):
  lcd.move_to(0,0)
  lcd.putstr('Temperature:'+str(temp))
  lcd.move_to(0,1)
  lcd.putstr('Humidity:'+str(hum)+'%')
while True:
  try:
    sleep(1)
    sensor.measure()
    temp=sensor.temperature()
    hum=sensor.humidity()
    testLcd(temp,hum)
  except OSError as e :
    print('Failed to read sensor.')
