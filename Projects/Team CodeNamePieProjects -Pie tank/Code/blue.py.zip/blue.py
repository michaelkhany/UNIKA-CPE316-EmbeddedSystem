from bluedot import BlueDot
from signal import pause
import RPi.GPIO as GPIO
import time

#Raspberry PI GPIO Pins
in1 = 24
in2 = 23
en = 25

in4 = 8
in3 = 7
en2 = 1

buzzer = 4
laser1 = 17
laser2 = 27

#Pins setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(in1,GPIO.OUT)
GPIO.setup(in2,GPIO.OUT)
GPIO.setup(en,GPIO.OUT)

GPIO.setup(in3,GPIO.OUT)
GPIO.setup(in4,GPIO.OUT)
GPIO.setup(en2,GPIO.OUT)

GPIO.setup(laser1,GPIO.OUT)
GPIO.setup(laser2,GPIO.OUT)

GPIO.setup(buzzer,GPIO.OUT)

#Default Motor PIN low high
GPIO.output(in1,GPIO.LOW)
GPIO.output(in2,GPIO.LOW)

GPIO.output(in3,GPIO.LOW)
GPIO.output(in4,GPIO.LOW)

#Buzzer and Motor Driver Start
p=GPIO.PWM(en,1000)
p2=GPIO.PWM(en2,1000)
b = GPIO.PWM(buzzer,550)
p.start(100)
p2.start(100)
print("\n")
print("Lutfen cihazını baglayın")
print("\n")

#Motors drive forward
def top():
    GPIO.output(in1,GPIO.HIGH)
    GPIO.output(in2,GPIO.LOW)
    GPIO.output(in3,GPIO.HIGH)
    GPIO.output(in4,GPIO.LOW)
#Motors drive back
def bottom():
    GPIO.output(in1,GPIO.LOW)
    GPIO.output(in2,GPIO.HIGH)
    GPIO.output(in3,GPIO.LOW)
    GPIO.output(in4,GPIO.HIGH)
#Motors drive right
def right():
    GPIO.output(in1,GPIO.LOW)
    GPIO.output(in2,GPIO.HIGH)
    GPIO.output(in3,GPIO.HIGH)
    GPIO.output(in4,GPIO.LOW)
#Motors drive left
def left():
    GPIO.output(in1,GPIO.HIGH)
    GPIO.output(in2,GPIO.LOW)
    GPIO.output(in3,GPIO.LOW)
    GPIO.output(in4,GPIO.HIGH)
#All component stop
def stop():
    GPIO.output(in1,GPIO.LOW)
    GPIO.output(in2,GPIO.LOW)
    GPIO.output(in3,GPIO.LOW)
    GPIO.output(in4,GPIO.LOW)
    GPIO.output(laser1,GPIO.LOW)
    GPIO.output(laser2,GPIO.LOW)
    bd[4,1].color = "red"
#Button activates lasers and buzzer 
def button():
    bd[4,1].color = "blue"
    GPIO.output(laser1,GPIO.HIGH)
    GPIO.output(laser2,GPIO.HIGH)
    b.start(1)
    time.sleep(1)
    GPIO.output(laser1,GPIO.LOW)
    GPIO.output(laser2,GPIO.LOW)
    b.stop()
    
#Including Bluetooth Module and Creating UI App
bd =  BlueDot(cols=5,rows=3)
bd.color = "gray"
bd.square = True
bd[4,1].color = "red"
bd[4,1].square = False


bd[0,0].visible = False
bd[2,0].visible = False
bd[0,2].visible = False
bd[2,2].visible = False
bd[1,1].visible = False
bd[3,0].visible = False
bd[3,1].visible = False
bd[3,2].visible = False
bd[4,0].visible = False
bd[4,2].visible = False


#When press button, this function runs
bd[1,0].when_pressed = top
bd[1,2].when_pressed = bottom

bd[0,1].when_pressed = right
bd[2,1].when_pressed = left

bd[4,1].when_pressed = button
bd.when_released = stop

#When release button, all function stop
bd.when_released = stop
pause()
GPIO.cleanup()
